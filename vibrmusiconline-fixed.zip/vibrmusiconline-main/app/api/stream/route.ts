import { NextResponse } from 'next/server';
import { getYouTube } from '@/lib/ytmusic';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');

  if (!id) {
    return NextResponse.json({ error: 'Missing ID' }, { status: 400 });
  }

  // Playlist-/Album-/Kanal-IDs sind keine Videos und dürfen nie als Audio geladen werden
  if (!/^[\w-]{11}$/.test(id)) {
    return NextResponse.json(
      { error: 'Das ist keine abspielbare Audiospur (Playlist, Album oder Kanal).' },
      { status: 400 }
    );
  }

  try {
    const yt = await getYouTube();
    const info = await yt.music.getInfo(id);

    if (info.basic_info.is_live) {
      return NextResponse.json({ error: 'Livestreams werden nicht unterstützt.' }, { status: 415 });
    }

    const format = info.chooseFormat({ type: 'audio', quality: 'best' });
    if (!format) {
      return NextResponse.json({ error: 'Stream format not found' }, { status: 404 });
    }

    const url = await format.decipher(yt.session.player);
    return NextResponse.redirect(url);
  } catch (error) {
    console.error('Stream error:', error);
    return NextResponse.json({ error: 'Failed to fetch stream' }, { status: 500 });
  }
}
