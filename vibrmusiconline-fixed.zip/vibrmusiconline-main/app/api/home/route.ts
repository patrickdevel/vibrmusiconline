import { NextResponse } from 'next/server';
import { getYouTube, mapItem } from '@/lib/ytmusic';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const yt = await getYouTube();
    const homeFeed = await yt.music.getHomeFeed();

    const sections = (homeFeed.sections || [])
      .map((section: any) => ({
        title: section.header?.title?.text || 'Empfehlungen',
        items: (section.contents || []).map(mapItem).filter(Boolean),
      }))
      .filter((s: any) => s.items.length > 0);

    return NextResponse.json({ sections });
  } catch (error) {
    console.error('Home feed error:', error);
    return NextResponse.json({ sections: [], error: 'Home feed failed' }, { status: 500 });
  }
}
