import { NextResponse } from 'next/server';
import { getYouTube, mapItem } from '@/lib/ytmusic';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = searchParams.get('q');

  if (!q) {
    return NextResponse.json({ results: [] });
  }

  try {
    const yt = await getYouTube();
    // Ungefilterte Suche: enthält Songs, Videos, Alben, Playlists, Künstler
    const search = await yt.music.search(q);

    const seen = new Set<string>();
    const results: any[] = [];
    for (const shelf of search.contents || []) {
      const items: any[] = (shelf as any).contents || [];
      for (const raw of items) {
        const item = mapItem(raw);
        if (!item || item.kind === 'artist') continue;
        const key = `${item.kind}:${item.id}`;
        if (seen.has(key)) continue;
        seen.add(key);
        results.push(item);
      }
    }

    return NextResponse.json({ results });
  } catch (error) {
    console.error('Search error:', error);
    return NextResponse.json({ results: [], error: 'Search failed' }, { status: 500 });
  }
}
